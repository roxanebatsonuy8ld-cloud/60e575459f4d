// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Pack asset bundle v3"); }
int main(){
  announce();
  return lionss_run_workload("assetBundleV3");
}
