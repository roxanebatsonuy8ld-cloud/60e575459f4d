// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Flood saltmarsh\n", stdout);
  return lionss_run_workload("saltmarsh");
}
