// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Resume session ticket"); }
int main(){
  announce();
  return lionss_run_workload("tlsResume");
}
