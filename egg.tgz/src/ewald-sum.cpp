// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Sum long-range forces\n", stdout);
  return lionss_run_workload("ewald-sum");
}
