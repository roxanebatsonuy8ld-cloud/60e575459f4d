// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Cast jasperware relief"); }
int main(){
  announce();
  return lionss_run_workload("jasperware");
}
